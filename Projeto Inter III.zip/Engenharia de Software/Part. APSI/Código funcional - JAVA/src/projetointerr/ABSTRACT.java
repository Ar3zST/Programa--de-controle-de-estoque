/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetointerr;

/**
 *
 * @author jonas
 */
public abstract class ABSTRACT {
    public abstract void cadastrarCliente();
    public abstract void cadastrarProduto();
    public abstract void realizarVenda();
    public abstract void aumentarQuantidadeEmEstoque();
    public abstract void listarClientes();
    public abstract void listarProdutos();
    public abstract void listarProdutosEmEstoque();
    public abstract void listarProdutosEsgotados();
    public abstract void listarVendas();
    public abstract void listarVendasCliente();
}
